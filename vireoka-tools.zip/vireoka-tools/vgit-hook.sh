#!/bin/bash
echo "🚀 GIT PUSH → Auto-deploy plugins"
$(dirname "$0")/vsync-plugins.sh
