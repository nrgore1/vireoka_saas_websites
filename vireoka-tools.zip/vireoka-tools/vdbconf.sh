REMOTE_DB_NAME="xxxx"
REMOTE_DB_USER="xxxx"
REMOTE_DB_PASS="xxxx"
REMOTE_DB_HOST="localhost"

# Local DB (your local WP DB, adjust accordingly)
LOCAL_DB_NAME="vireoka_local"
LOCAL_DB_USER="root"
LOCAL_DB_PASS=""
LOCAL_DB_HOST="127.0.0.1"